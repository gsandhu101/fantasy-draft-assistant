import pandas as pd

def compute_rankings(session):
    # Placeholder ranking logic
    data = [
        {"Player": "Patrick Mahomes", "Score": 98},
        {"Player": "Justin Jefferson", "Score": 95},
    ]
    return pd.DataFrame(data)
