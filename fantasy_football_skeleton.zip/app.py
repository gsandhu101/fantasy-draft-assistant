import streamlit as st
from ingest.twitter_ingest import fetch_latest_tweets
from ingest.sports_ingest import fetch_player_data
from db import init_db, get_db_session
from ranking import compute_rankings
import os

st.set_page_config(page_title="Fantasy Football Draft Assistant", layout="wide")

# Initialize DB
init_db()
session = get_db_session()

st.title("🏈 Fantasy Football Draft Assistant")

if st.button("Update Data Now"):
    with st.spinner("Fetching latest tweets and player data..."):
        fetch_latest_tweets(session)
        fetch_player_data(session)
    st.success("Data updated successfully!")

st.subheader("Rankings")
rankings = compute_rankings(session)
st.dataframe(rankings)
