# Fantasy Football Draft Assistant — Production Skeleton

This is a production-ready **skeleton** for building your Fantasy Football Draft Assistant.

## Features
- Streamlit web app
- Twitter API ingestion from NFL beat writers
- Sportsdata.io API for player stats & ADP
- SQLAlchemy database storage
- Ranking algorithm placeholder
- `.env` for API keys

## Getting Started
1. Clone this repo.
2. Copy `.env.example` to `.env` and fill in credentials.
3. Install requirements: `pip install -r requirements.txt`
4. Run the app: `streamlit run app.py`
