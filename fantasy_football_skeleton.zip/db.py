from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
import os
from dotenv import load_dotenv

load_dotenv()

DB_URL = os.getenv("DATABASE_URL", "sqlite:///fantasy.db")
Base = declarative_base()

def init_db():
    engine = create_engine(DB_URL)
    Base.metadata.create_all(engine)

def get_db_session():
    engine = create_engine(DB_URL)
    Session = sessionmaker(bind=engine)
    return Session()
