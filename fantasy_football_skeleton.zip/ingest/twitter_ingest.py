import tweepy
import os
from dotenv import load_dotenv
from sqlalchemy import Table, Column, Integer, String, DateTime, MetaData
from datetime import datetime

load_dotenv()

BEAT_WRITERS = [
    "AdamSchefter", "RapSheet", "TomPelissero"
]

def fetch_latest_tweets(session):
    auth = tweepy.OAuth2BearerHandler(os.getenv("TWITTER_BEARER_TOKEN"))
    api = tweepy.API(auth)
    for user in BEAT_WRITERS:
        tweets = api.user_timeline(screen_name=user, count=5, tweet_mode="extended")
        for tweet in tweets:
            print(f"[Tweet] {tweet.user.screen_name}: {tweet.full_text[:50]}...")
