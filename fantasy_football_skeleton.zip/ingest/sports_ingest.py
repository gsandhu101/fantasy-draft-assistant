import requests
import os
from dotenv import load_dotenv

load_dotenv()

SPORTS_API_KEY = os.getenv("SPORTS_API_KEY")

def fetch_player_data(session):
    url = f"https://api.sportsdata.io/v3/nfl/stats/json/PlayerSeasonStats/2024REG?key={SPORTS_API_KEY}"
    r = requests.get(url)
    if r.status_code == 200:
        data = r.json()
        print(f"Fetched {len(data)} players")
    else:
        print("Error fetching player data", r.status_code)
